package cc.creativecomputing.cv.filter;

import cc.creativecomputing.cv.CCPixelRaster;

public interface CCIRasterFilter {
    public CCPixelRaster filter(CCPixelRaster theRaster);
}
